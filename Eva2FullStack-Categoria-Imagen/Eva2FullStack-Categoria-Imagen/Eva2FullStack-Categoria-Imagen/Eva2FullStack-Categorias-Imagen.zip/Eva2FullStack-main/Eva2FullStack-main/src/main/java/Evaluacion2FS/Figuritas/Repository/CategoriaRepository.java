package Evaluacion2FS.Figuritas.Repository;

public class CategoriaRepository {

}
